# 文档驱动物品选择试用报告

结果：**PARTIAL / BLOCKED**。可用的部分是 CPU 离屏的非模态列表试验，不能从游戏打开。没有声称真人盲测、游戏内通过或目标弹窗完成。

## 最大缺口

公开 `UiSession.open(ConfirmationDialog, Consumer<ConfirmationResult>)` 只接收 `ConfirmationDialog`；其 `ConfirmationModel` 仅有 title、message、cancelLabel、confirmLabel。公开签名没有让宿主注入分类控件、列表、说明及操作区的内容入口，也没有公开的通用可组合模态入口。基于本任务禁止自造模态/命中/隔离，无法合法实现要求的可打开关闭且隔离底层的物品选择弹窗。最小诉求：库公开可放入任意受控控件树的模态容器，并统一拥有焦点、指针捕获、遮罩/尾事件和滚动视口隔离及关闭语义。不能根据本次签名探查推断未来版本能力。

文档与候选 JAR 公开类名扫描未发现 Minecraft 物品 ID 到真实物品图标的现成控件/API（仅见通用 `AppIcons`）；需要库提供符合渲染桥生命周期的物品图标公开接口，或用户另行授权的宿主桥方案。本试验没有以色块冒充图标。

## 逐项结果

| 项目 | 结果与范围 |
|---|---|
| 24 条、方块/工具/食物、全部及分类 | PASS：CPU 试验页；额外空分类用于表达空结果。 |
| 列表浏览和单选、文字说明 | PASS：库按钮纵向列表，正常图可见选中；没有网格。 |
| 筛选隐藏选中项、空结果与禁用确认 | PASS：真实指针筛选清除，空分类按钮拒绝按下，图中显示空结果和禁用确认。 |
| 确认返回 ID、取消不提交 | PASS：CPU 页面中控件触发业务状态；不是弹窗关闭和回调。 |
| 滚动、窄宽短窗 | PARTIAL：380×320 用真实滚轮逐步滚到最后一条并点击；截图显示顶部分类换行挤压，仅证明特定目标可达，不代表窄窗可用或美观。当前 5 个分段和尺寸参数可由创作者重新设计，不能简单归咎库缺陷。 |
| 键盘 | PARTIAL：CPU Tab/Enter 选择分类、物品、确认、取消通过；Escape 关闭/遮罩隔离因没有模态及 Screen 未实现。未覆盖其他快捷键、重复按键及完整无障碍。 |
| 弹窗开关、遮罩、底层隔离 | BLOCKED：仅固定确认窗公开入口；没有伪造。 |
| 真实物品图标 | BLOCKED：未发现现成公开物品图标接口。 |
| Fabric 构建/打包 | PASS：离线构建通过，JAR 无客户端入口，不是可玩的完整模组。 |
| 游戏、GPU、真实界面、观感 | NOT RUN：按要求没有启动 Minecraft、runClient 或部署；CPU 图不能替代游戏验收。 |

## 真实试用路径和边界事故

实际阅读：`D:/AtomLib/README.md`、`docs/quickstart.md`、`controls.md`、`api-contracts.md`、`design-package.md`、`runtime.md`、`render-bridge.md`、`backdrop.md`、`getting-started.md`、`ai-guide.md`。这些文档有旧 beta 描述与候选增量并存的情况，应以候选控件段及候选 JAR 公共签名对照；没有打开文档提到的旧样例、源码、测试、计划或证据。公共签名探查涉及 `UiSession`、`ConfirmationDialog/Model`、`Control`、`ActionButton/Model`、`SegmentedChoice/ChoiceModel`、`SettingsShell/Frame`、`SettingsGroup/PageStyle`、`Disclosure`、`ControlScreenAdapter`、`ScrollViewport`、`PresentationFrame`、runtime/font/text 等；使用 `javap` 默认声明输出，没有反编译方法体。

**必须披露：首次离线 `compileTestJava` 使用 `modImplementation` 后，Loom 输出 `:remapping sources`，并在本工程 `.gradle/loom-cache/remapped_mods/` 生成 AtomLib `-sources.jar`。这表明工具自动触及了用户禁止的源码包；虽然没有打开、阅读或复制任何源码内容，这次试用不能声称完全遵守禁读边界。** 发现后改用普通 `implementation` 消费认证二进制，最终构建输出 `remapSourcesJar SKIPPED`，并验证 compile/runtime 实际解析的原始 JAR 路径与哈希。首次生成物保留在新工程内以便核查，没有操作其他工程或旧输入锁。该错误的避免方法是先禁止 Loom 将目标库作为 mod 重映射来源，再运行 Gradle；本轮事后调整不能撤销首次自动处理。

初次 Git Bash 路径方式在本工具环境下找不到 `/c`、`/d`，随后使用 PowerShell；没有联网下载。初始测试因 TrialState 尚不存在编译失败。首次视觉配置 `cardTint=1` 导致文字和背景对比不足，改成 0.15 后可读；短窄分类仍拥挤。首次滚动直接跳到末尾让最后物品移到可视区域上方，改为逐格滚动并检查其中心处于真实 clip；键盘首次按 32 次 Tab 错过确认，按控件焦点顺序修正为从石头后继续 25 次，实际 Enter 成功。

## 验证与输入输出

JDK `C:/Program Files/Java/jdk-21.0.11`，Gradle wrapper 8.8，Fabric Loom 1.7.4、Loader 0.16.9、Yarn 1.21.1+build.3。最终命令 `gradlew.bat build trialChecks --offline --no-daemon --console=plain` 退出 0，日志 [build-and-checks.log](evidence/build-and-checks.log)。Gradle 普通 `test` 不包含 JUnit 用例；实际断言由 `trialChecks` 的 Java 主程序运行，不以 test 任务绿灯代替交互证据。鼠标事件使用库 `ControlScreenAdapter`，坐标从库发布的 `PresentationFrame` 读取；截图由真实库 paint 写入 1:1 CPU Surface。

负控把选中回调暂改为总选泥土，执行同一 `trialChecks`，退出 1 且 `mouse selected stone` 断言失败，见 [negative-control.log](evidence/negative-control.log)。恢复前后该源文件 SHA-256 均为 `0b6fcae9d59cfde1d55f04b92c7a33a868feebacc304c6f06ecc9b548f26cd90`、字节一致；之后又有一次正常修改以使展开控件受控，因此最终文件摘要另见 `results.json`。最终回归在恢复和该改动后重新运行通过。

原始候选 JAR SHA-256 `90ebec2894d4ca2143ff3281637658e8ca43acf45372d58ab8a64f7b88db2158`；依赖锁、Maven 元数据及产物/PNG 摘要见 [results.json](results.json)。构建时检查编译和运行路径指向该认证原始文件；未把 Lib 打进试用 JAR。日志、正常/选中/空结果/短窄/键盘焦点图均保存在 `evidence/`。CPU 截图是透明背景的试验画面，不能展示游戏背景或模态遮罩。

没有修改 AtomLib、AtomChat、旧试用、共享记忆或旧锁；没有运行 Minecraft、启动 UI、部署、提交、推送或发布。没有验证游戏中输入映射、GUI 缩放、资源重载、渲染桥、窗口失焦及实际手感。

## 2026-11-02 正式样例分类焦点修复

上述原始试用结果和原日志保留为历史；[REVIEW.md](REVIEW.md) 中的独审副本红绿也是历史。正式 `TrialPage` 原来每次 dirty 重建分类实例，分类选择触发重建后焦点落到 detail Disclosure；现复用实例并通过公开 `SegmentedChoice.update` 更新模型，其余控件组合不变。

正式 `TrialChecks` 先增加真实 `ControlScreenAdapter` 的按键 down/up 与逐步 paint：Tab 两次、Enter 选方块，paint 后再次 Enter 不按 Tab，验证石头仍在绘制列表；再 Tab、Enter 验证工具分类被选中，证明焦点仍位于方块分类。JDK `C:/Program Files/Java/jdk-21.0.11` 下两次执行 `gradlew.bat build trialChecks --offline --no-daemon --console=plain`：修复前退出 1，第二次 Enter 后列表展开断言失败（[红灯](evidence/category-focus-fix-20261102/red.log)）；修复后退出 0，七组 JavaExec 场景通过（[绿灯](evidence/category-focus-fix-20261102/green.log)）。这不是 JUnit；没有启动游戏。最终构建显示 `remapSourcesJar SKIPPED`，首次 Loom 自动处理 sources 的历史事故仍如上披露。

输入候选 SHA-256 `90ebec2894d4ca2143ff3281637658e8ca43acf45372d58ab8a64f7b88db2158`，最终试用 JAR SHA-256 `0b59d0a919d5cee35640ec0a67ba298e3b7bbca5db4f57ea4290d65b5e5a4b90`；编译和运行类路径均校验原始输入。重跑前五张原图备份在 [original-png](evidence/category-focus-fix-20261102/original-png/)，其中四张字节相同；`empty.png` 有 4352 像素不同，范围 x=63..736、y=114..203，未做视觉验收或推断全部原因。原报告及 JSON 也有修前快照，旧独审证据未覆盖。整体仍为 CPU 非模态 PARTIAL / BLOCKED，缺可组合模态和真实物品图标，也未验证游戏、GPU、真实输入或可访问性。
