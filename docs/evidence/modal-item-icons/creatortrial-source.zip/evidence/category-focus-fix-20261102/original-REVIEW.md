# 主代理独立复核（2026-11-02）

结论：REVIEWED_WITH_ONE_P2。原交付仍为非模态CPU试验页，PARTIAL/BLOCKED，不是完整物品弹窗。本次已读取全部业务、验证与构建代码，离线重跑原验证并检查实际输入/消费JAR；未启动游戏。

## P2：分类控件重建导致焦点跳到折叠标题

位置：`src/main/java/dev/creatortrial/TrialPage.java:35`，同一rebuild最后在43行把新实例交给setControls。选择分类后dirty导致分类按钮全部重建，已显示实例被替换，键盘焦点转移到detail折叠标题。

最小复现：初次绘制→Tab两次到方块→完整Enter→绘制→不按Tab再次完整Enter→绘制。预期仍是展开的方块列表；实际列表被折叠。原trialChecks的分类键盘用例在首次激活后结束，没有检查保留焦点后的连续输入。

原工程`build trialChecks --offline --no-daemon --console=plain`通过；独立副本的追加探针实际断言失败（keyboard-probe-red.log）。仅在审查副本保留categories实例并调用公开update，追加探针与原七组trialChecks均通过（keyboard-probe-green.log）。这是样例接线问题，不能列为Lib必须新增的组件能力。

**正式试用源码尚未修改。** 修复只应用于`build/main-review/project`，正式12项源文件/配置SHA均不变；原六张证据PNG重跑后字节相同。

## 能力缺口与边界

可组合模态仍是明确的高层API缺口；公开会话只接收固定确认窗，不能合法挂入分类/物品控件并获得完整模态隔离。真实物品图标未有现成语义API，底层vanillaPass能力不等于创作者可直接组合的图标组件。窄宽标签挤压仍属于本次组合设计待完善，不能单归因Yoga。

业务代码没有自写Canvas绘制、GL、命中、焦点或滚动实现；实际jar只有三份业务class，无Lib/native/font/shader夹带。首次Loom自动处理sources包的边界事故依然保留披露，不称严格盲测。此轮没有重新执行旧的回调负控；原验证与新增探针是本轮真实执行。

完整计数和状态在`build/main-review/review.json`；日志和探针源代码在同目录。未改Lib/AC/输入锁，无提交/发布/部署/游戏操作。
