# 2026-11-02 M2 原版物品图标候选

本轮已新增可编译的 TrialScreen/TrialClient 与专用 mixin 包，F8入口只允许标题页或无其它业务Screen。页面根据当前PresentationFrame的可见图像槽准备原生ItemStack请求，通过AtomLib离屏服务在同一Skija控件层采样；普通implementation继续认证原始二进制。input-lock.json指向modal-item-icons-candidate，修前M1锁/报告在evidence/modal-item-icons-candidate/before。

`build trialChecks --offline --no-daemon --console=plain`通过9组JavaExec场景（原8组+客户端入口元数据检查），不是JUnit。CPU截图输出到evidence/modal-item-icons-candidate/output，空图标槽不冒充Minecraft像素。Screen仅编译，游戏内F8、原版物品实际显示、资源reload及性能均未运行。纯GL成功不等于MC模型显示成功。

生产Fabric二进制原生类型构造器与named开发映射存在描述符差异，consumer-first.log记录class_1799编译红灯；本轮增加平台校验的fromNativeStack工厂并在consumer-second.log编译/运行通过。没有让Loom处理本轮Lib sources；历史sources自动处理事故仍见以下记录，不称严格盲测。

库报告：D:/AtomLib/docs/evidence/modal-item-icons/report.md；精确结果与SHA：evidence/modal-item-icons-candidate/results.json。

---
以下为M1及更早阶段历史记录。

# AtomLib 创作者试用：M1 CPU 可组合模态

本工程现在消费 `input-lock.json` 指向的 `composable-modal-candidate` 原始 Fabric 二进制，以 `implementation` 接线，不让 Loom 处理 AtomLib sources。宿主提供“选择物品”入口、24 条业务记录、分类、草稿及提交/取消；模态输入、焦点和滚动属于库。`trialChecks` 是 JavaExec，覆盖 1000×700 和 380×320，各 1/1.5/2 密度。运行命令为 JDK21 下 `./gradlew.bat build trialChecks --offline --no-daemon --console=plain`。

当前仍无可运行的游戏 Screen，原版物品图标 M2 未实施；CPU PNG 不是游戏或物品图标截图。Loom 曾在早期自动处理 sources 的事故仍见下方历史报告。本轮证据和旧锁/报告快照见 `evidence/composable-modal-candidate/`。

---
以下为旧版非模态试用的历史记录，不代表当前锁或页面。

# AtomLib 创作者试用：物品选择（部分完成）

这是 Fabric 1.21.1/JDK 21 的独立二进制消费者，交付的是 **CPU 非模态试验页面**，不是可在游戏中打开的物品弹窗。JAR 没有客户端入口或 Screen；它用于编译、打包与离屏验证，不能直接作为完整模组使用。原因和实际验收范围见 [REPORT.md](REPORT.md) 与 [results.json](results.json)。

## 复现

需要 Windows x64、JDK `C:/Program Files/Java/jdk-21.0.11`、Gradle 8.8 已缓存，以及 Fabric Loom、Minecraft、Yarn 和依赖已缓存。AtomLib 仓库必须位于 `D:/AtomLib/build/interaction-fixes-candidate/maven`；本工程不会联网准备缺少的缓存。不能用其他同版本 JAR 代替：`input-lock.json` 和构建脚本共同固定候选原始 JAR 的 SHA-256，构建还核对编译和运行类路径实际解析的路径和摘要。

在工程目录的 PowerShell 中：

```powershell
$env:JAVA_HOME='C:/Program Files/Java/jdk-21.0.11'
.\gradlew.bat build trialChecks --offline --no-daemon --console=plain
```

`trialChecks` 使用真实 AtomLib 控件、布局、CPU 栅格与输入适配器，生成 `evidence/*.png`；坐标密度为每单位 1 物理像素。截图是试验页面，不是弹窗或游戏截图。`build/libs/creator-trial-0.1.0-trial.jar` 不打包 AtomLib，且没有打开入口。

## 内容

`TrialState` 管理 24 条固定记录、筛选、选择和提交；`TrialPage` 将其交给库的 SettingsShell、SegmentedChoice、ActionButton、Disclosure、UiSession 与 ControlScreenAdapter。选择被筛掉时清空；空分类提供可见的空结果；无选择时确认禁用。页面只为验证能做到的部分而存在，没有自行实现模态、图标、滚动或命中机制。

首次配置曾因 Loom 自动处理源码包越过本任务禁读边界；具体事实及之后的接线调整见报告。

## 2026-11-02 分类键盘焦点修复

正式样例复用分类控件，并用公开 `update` 更新模型。新增 CPU 连续 Tab/Enter 输入回归：选择方块后再次 Enter 不折叠列表，继续 Tab/Enter 能选择工具。红绿日志和原始截图备份见 [本轮证据](evidence/category-focus-fix-20261102/)；具体范围见报告。整体仍为 PARTIAL / BLOCKED。
