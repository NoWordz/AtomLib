package dev.creatortrial.mixin;
import dev.creatortrial.TrialClient;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @Inject(method="tick",at=@At("TAIL"))
    private void creatortrial$tick(CallbackInfo info){TrialClient.tick((MinecraftClient)(Object)this);}
}
