package dev.creatortrial;
import java.util.*;
public final class TrialState {
    public record Item(String id, String category, String name, String description) {}
    private static final List<Item> ITEMS = List.of(
        new Item("minecraft:stone","blocks","石头","常见的建筑方块。"), new Item("minecraft:dirt","blocks","泥土","适合种植的基础方块。"),
        new Item("minecraft:oak_log","blocks","橡木原木","可制作木板。"), new Item("minecraft:glass","blocks","玻璃","透明的建筑方块。"),
        new Item("minecraft:sand","blocks","沙子","受重力影响。"), new Item("minecraft:gravel","blocks","砂砾","受重力影响的方块。"),
        new Item("minecraft:bricks","blocks","砖块","适合建造墙面。"), new Item("minecraft:obsidian","blocks","黑曜石","坚硬的深色方块。"),
        new Item("minecraft:wooden_pickaxe","tools","木镐","基础挖掘工具。"), new Item("minecraft:stone_pickaxe","tools","石镐","升级后的挖掘工具。"),
        new Item("minecraft:iron_pickaxe","tools","铁镐","用途广泛的挖掘工具。"), new Item("minecraft:diamond_pickaxe","tools","钻石镐","耐用的挖掘工具。"),
        new Item("minecraft:wooden_axe","tools","木斧","基础伐木工具。"), new Item("minecraft:iron_shovel","tools","铁锹","用于挖掘松软方块。"),
        new Item("minecraft:shears","tools","剪刀","用于剪取羊毛等材料。"), new Item("minecraft:fishing_rod","tools","钓鱼竿","用于垂钓。"),
        new Item("minecraft:apple","food","苹果","常见的食物。"), new Item("minecraft:bread","food","面包","由小麦制作。"),
        new Item("minecraft:carrot","food","胡萝卜","可以直接食用。"), new Item("minecraft:potato","food","马铃薯","可以烹饪。"),
        new Item("minecraft:cooked_beef","food","牛排","烹饪后的牛肉。"), new Item("minecraft:cooked_chicken","food","熟鸡肉","烹饪后的鸡肉。"),
        new Item("minecraft:melon_slice","food","西瓜片","清爽的食物。"), new Item("minecraft:cookie","food","曲奇","小份点心。"));
    private String category="all", selected, submitted;
    public List<Item> items(){return ITEMS;}
    public List<Item> visible(){return ITEMS.stream().filter(i -> category.equals("all") || i.category().equals(category)).toList();}
    public String category(){return category;} public String selected(){return selected;} public String submitted(){return submitted;}
    public void category(String value){category=Objects.requireNonNull(value); if (visible().stream().noneMatch(i -> i.id().equals(selected))) selected=null;}
    public void select(String id){if(visible().stream().noneMatch(i -> i.id().equals(id))) throw new IllegalArgumentException("not visible"); selected=id;}
    public Item selection(){return ITEMS.stream().filter(i -> i.id().equals(selected)).findFirst().orElse(null);}
    public void begin(){category="all";selected=submitted;}
    public void confirm(){if(selected!=null) submitted=selected;} public void cancel(){selected=submitted;}
}
