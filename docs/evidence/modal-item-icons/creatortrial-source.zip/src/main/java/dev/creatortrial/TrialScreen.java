package dev.creatortrial;
import com.atom.lib.client.render.MinecraftRenderBridge;
import com.atom.lib.client.render.item.*;
import com.atom.lib.input.KeyEvent;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import java.util.*;
/** Thin native adapter. All modal, focus, scroll and GL ownership is in AtomLib. */
public final class TrialScreen extends Screen {
    private final TrialPage page=new TrialPage();
    private boolean closed;
    public TrialScreen(){super(Text.literal("Creator Trial"));}
    @Override public void render(DrawContext context,int mouseX,int mouseY,float delta){
        context.draw();float density=(float)client.getWindow().getFramebufferWidth()/Math.max(1,width);
        var frame=page.layout(width,height,density);var visible=page.visibleIconIds(frame);var requests=new ArrayList<ItemIconRequest>();
        for(var id:visible){var node=new com.atom.lib.layout.NodeId("item/"+id);float scale=frame.presentation().renderScale(node);requests.add(ItemIconRequest.fromNativeStack(id,new ItemStack(Registries.ITEM.get(Identifier.of(id))),MinecraftItemIcons.pixels(24*scale,density)));}
        var bridge=MinecraftRenderBridge.get();long now=System.nanoTime();
        try(var icons=bridge.itemIcons().prepare(requests,now)){
            page.bindIcons(visible,icons::icon);bridge.draw(canvas->{int save=canvas.getSaveCount();canvas.save();try{canvas.scale(density,density);page.paintPrepared(canvas,frame);}finally{canvas.restoreToCount(save);}});
        }finally{page.clearIconHandles();}
    }
    @Override public boolean mouseClicked(double x,double y,int button){return page.input.press(x,y,button)||super.mouseClicked(x,y,button);}
    @Override public boolean mouseReleased(double x,double y,int button){return page.input.release(x,y,button)||super.mouseReleased(x,y,button);}
    @Override public boolean mouseDragged(double x,double y,int button,double dx,double dy){return page.input.drag(x,y,button,dx,dy)||super.mouseDragged(x,y,button,dx,dy);}
    @Override public boolean mouseScrolled(double x,double y,double dx,double dy){return page.input.scroll(x,y,dx,dy)||super.mouseScrolled(x,y,dx,dy);}
    @Override public void mouseMoved(double x,double y){page.input.hover(x,y);super.mouseMoved(x,y);}
    private boolean key(int code,boolean down,int modifiers){
        KeyEvent.Key key=switch(code){case GLFW.GLFW_KEY_TAB->KeyEvent.Key.TAB;case GLFW.GLFW_KEY_ENTER,GLFW.GLFW_KEY_KP_ENTER->KeyEvent.Key.ENTER;case GLFW.GLFW_KEY_SPACE->KeyEvent.Key.SPACE;case GLFW.GLFW_KEY_ESCAPE->KeyEvent.Key.ESCAPE;case GLFW.GLFW_KEY_LEFT->KeyEvent.Key.LEFT;case GLFW.GLFW_KEY_RIGHT->KeyEvent.Key.RIGHT;case GLFW.GLFW_KEY_UP->KeyEvent.Key.UP;case GLFW.GLFW_KEY_DOWN->KeyEvent.Key.DOWN;case GLFW.GLFW_KEY_HOME->KeyEvent.Key.HOME;case GLFW.GLFW_KEY_END->KeyEvent.Key.END;default->null;};
        return key!=null&&page.input.key(new KeyEvent(key,down,(modifiers&GLFW.GLFW_MOD_SHIFT)!=0,(modifiers&GLFW.GLFW_MOD_CONTROL)!=0,(modifiers&GLFW.GLFW_MOD_ALT)!=0));
    }
    @Override public boolean keyPressed(int code,int scan,int mods){return key(code,true,mods)||super.keyPressed(code,scan,mods);}
    @Override public boolean keyReleased(int code,int scan,int mods){return key(code,false,mods)||super.keyReleased(code,scan,mods);}
    @Override public boolean charTyped(char chr,int mods){return page.input.character(chr)||super.charTyped(chr,mods);}
    public void windowFocused(boolean focused){page.input.windowFocused(focused);}
    @Override public boolean shouldPause(){return false;}
    @Override public void removed(){if(closed)return;closed=true;try{page.input.removed();}finally{page.close();super.removed();}}
}
