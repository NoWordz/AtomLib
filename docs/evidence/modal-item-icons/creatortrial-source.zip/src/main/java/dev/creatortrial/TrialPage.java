package dev.creatortrial;
import com.atom.lib.*;
import com.atom.lib.controls.*;
import com.atom.lib.design.atomchat.*;
import com.atom.lib.font.FontRegistry;
import com.atom.lib.text.TextService;
import com.atom.lib.geometry.Viewport;
import com.atom.lib.layout.*;
import com.atom.lib.motion.FrameTime;
import io.github.humbleui.skija.Canvas;
import java.util.*;

/** Business state and composition only; modal input and scrolling are owned by AtomLib. */
public final class TrialPage implements AutoCloseable {
    public final TrialState state=new TrialState();
    public final RuntimeHandle runtime=AtomLibRuntime.open("creator-trial");
    private final FontRegistry fonts=new FontRegistry(runtime);
    private final TextService text=new TextService(fonts);
    private final ControlContext context;
    private final SettingsShell shell;
    public final UiSession session;
    public final ControlScreenAdapter input;
    private final SegmentedChoice home,categories;
    private final Disclosure section;
    private final SettingsGroup group;
    private final ActionButton open,confirm,cancel,description;
    private final Map<String,ActionButton> items=new LinkedHashMap<>();
    private final ModalDialog dialog;
    private final List<ChoiceModel.Option> options=List.of(new ChoiceModel.Option("all","全部",true),new ChoiceModel.Option("blocks","方块",true),new ChoiceModel.Option("tools","工具",true),new ChoiceModel.Option("food","食物",true),new ChoiceModel.Option("empty","空分类",true));
    private long frame;private boolean modalOpen;
    public TrialPage(){
        fonts.registerDefaults();AtomChatFonts.register(fonts);context=new ControlContext(text,new AtomChatControlSkin(AtomChatControlStyle.defaults()));
        shell=new SettingsShell(context);session=new UiSession(List.of());input=new ControlScreenAdapter(session);
        home=new SegmentedChoice(new NodeId("home"),context,new ChoiceModel(List.of(new ChoiceModel.Option("page","主页",true)),"page"),v->{});
        categories=new SegmentedChoice(new NodeId("category"),context,new ChoiceModel(options,"all"),v->state.category(v));
        section=new Disclosure(new NodeId("section"),context,"选择物品","",true,true,v->{});
        open=new ActionButton(new NodeId("open"),context,new ActionModel("选择物品",true,ActionModel.Role.NORMAL),this::openModal);
        group=new SettingsGroup(new NodeId("host-group"),section,List.of(open));
        confirm=new ActionButton(new NodeId("confirm"),context,new ActionModel("确认",false,ActionModel.Role.NORMAL),()->{state.confirm();session.closeModal(ModalCloseReason.COMPLETED);});
        cancel=new ActionButton(new NodeId("cancel"),context,new ActionModel("取消",true,ActionModel.Role.NORMAL),()->{state.cancel();session.closeModal(ModalCloseReason.CANCELLED);});
        description=new ActionButton(new NodeId("selection-info"),context,new ActionModel("尚未选择物品",false,ActionModel.Role.NORMAL),()->{});
        for(var item:state.items())items.put(item.id(),new ActionButton(new NodeId("item/"+item.id()),context,new ActionModel(item.name(),true,ActionModel.Role.NORMAL),()->state.select(item.id())));
        for(var button:items.values())button.icon(null,24);
        dialog=new ModalDialog(new NodeId("picker"),context,new ModalOptions("选择物品",640,16,true,new NodeId("category/all")));
        var controls=new ArrayList<Control>();controls.addAll(home.controls());controls.add(section.control());controls.add(open);session.setControls(controls);
    }
    private void openModal(){state.begin();modalOpen=true;refreshModal(false);try{session.open(dialog,r->modalOpen=false);}catch(RuntimeException|Error e){modalOpen=false;throw e;}}
    private void refreshModal(boolean narrow){
        categories.update(new ChoiceModel(options,state.category()));
        var body=new ArrayList<LayoutNode>();var controls=new ArrayList<Control>();
        if(narrow){
            dialog.navigation(null);var choices=categories.controls();controls.addAll(choices);
            body.add(new LayoutNode(new NodeId("category/row1"),LayoutStyle.row().spacing(0,4),choices.subList(0,3).stream().map(b->b.node(LayoutStyle.column().flex(1,1,Length.points(0)))).toList(),null,0));
            body.add(new LayoutNode(new NodeId("category/row2"),LayoutStyle.row().spacing(0,4),choices.subList(3,5).stream().map(b->b.node(LayoutStyle.column().flex(1,1,Length.points(0)))).toList(),null,0));
        }else dialog.navigation(categories);
        var selected=state.selection();description.update(new ActionModel(selected==null?(state.visible().isEmpty()?"没有符合分类的物品":"尚未选择物品"):selected.name()+"："+selected.description(),false,ActionModel.Role.NORMAL));
        body.add(description.node(LayoutStyle.column()));controls.add(description);
        for(var item:state.visible()){
            var button=items.get(item.id());button.update(new ActionModel(item.name(),true,ActionModel.Role.NORMAL,item.id().equals(state.selected())));
            body.add(button.node(LayoutStyle.column()));controls.add(button);
        }
        confirm.update(new ActionModel("确认",selected!=null,ActionModel.Role.NORMAL));
        dialog.content(new LayoutNode(new NodeId("picker/content"),LayoutStyle.column().spacing(0,4),body,null,0),controls);dialog.actions(List.of(cancel,confirm));
    }
    public SettingsShell.Frame paint(Canvas canvas,int width,int height){return paint(canvas,width,height,1);}
    public SettingsShell.Frame paint(Canvas canvas,int width,int height,float density){var result=layout(width,height,density);paintPrepared(canvas,result);return result;}
    public SettingsShell.Frame layout(int width,int height,float density){
        var vp=new Viewport(width,height,density);var style=new SettingsPageStyle(Math.min(720,width),false,1,1,1,.15f);
        shell.prepare(session,vp,style);if(modalOpen)refreshModal(width<500);
        return shell.layout(session,vp,style,"物品选择试验","已提交: "+(state.submitted()==null?"无":state.submitted()),home,List.of(group),List.of());
    }
    public void paintPrepared(Canvas canvas,SettingsShell.Frame result){shell.paint(canvas,result,session,new FrameTime(++frame,System.nanoTime(),.016),false);}
    public List<String> visibleIconIds(SettingsShell.Frame frame){
        return state.items().stream().map(TrialState.Item::id).filter(id->{var slot=new NodeId("item/"+id+"/icon");if(!frame.presentation().paintOrder().contains(slot))return false;var box=frame.presentation().box(slot);var shown=box.content().intersect(box.clip());return shown.width()>0&&shown.height()>0;}).toList();
    }
    public void bindIcons(List<String> visible,java.util.function.Function<String,ControlIcon> icons){for(var id:visible)items.get(id).icon(icons.apply(id),24);}
    public void clearIconHandles(){for(var button:items.values())button.icon(null,24);}
    public com.atom.lib.layout.ScrollViewport scroll(){return shell.scroll();}
    public void close(){session.close();shell.close();text.close();fonts.close();runtime.close();}
}
