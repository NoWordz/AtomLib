package dev.creatortrial;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
public final class TrialClient implements ClientModInitializer {
    private static boolean held;
    @Override public void onInitializeClient(){}
    public static void tick(MinecraftClient client){
        boolean down=InputUtil.isKeyPressed(client.getWindow().getHandle(),GLFW.GLFW_KEY_F8);
        if(down&&!held&&(client.currentScreen==null||client.currentScreen instanceof TitleScreen))client.setScreen(new TrialScreen());held=down;
        if(client.currentScreen instanceof TrialScreen trial)trial.windowFocused(client.isWindowFocused());
    }
}
