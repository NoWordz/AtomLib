package dev.creatortrial;
import com.atom.lib.layout.NodeId;
import com.atom.lib.design.atomchat.SettingsShell;
import com.atom.lib.input.KeyEvent;
import io.github.humbleui.skija.Surface;
import java.nio.file.*;
/** JavaExec integration checks using real raster surfaces and the binary library. */
public class TrialChecks {
  private static void check(boolean value,String why){if(!value)throw new AssertionError(why);}
  private static void save(Surface surface,String name)throws Exception{try(var img=surface.makeImageSnapshot();var data=img.encodeToData()){var dir=Path.of("evidence/modal-item-icons-candidate/output");Files.createDirectories(dir);Files.write(dir.resolve(name),data.getBytes());}}
  private static void click(TrialPage page,SettingsShell.Frame frame,String id){var b=frame.presentation().box(new NodeId(id));var r=b.hit();float x=r.x()+r.width()/2,y=r.y()+r.height()/2;check(b.clip().contains(x,y),"clipped "+id+" "+r+" "+b.clip());check(page.input.press(x,y,0),"press "+id);check(page.input.release(x,y,0),"release "+id);}
  private static void key(TrialPage p,KeyEvent.Key k){check(p.input.key(new KeyEvent(k,true,false,false,false)),"key "+k);p.input.key(new KeyEvent(k,false,false,false,false));}
  private static SettingsShell.Frame show(TrialPage p,Surface s,int w,int h,float density){s.getCanvas().save();try{s.getCanvas().scale(density,density);return p.paint(s.getCanvas(),w,h,density);}finally{s.getCanvas().restore();}}
  private static void scenario(int w,int h,float density)throws Exception{
    try(var p=new TrialPage();var s=Surface.makeRasterN32Premul(Math.round(w*density),Math.round(h*density))){
      check(p.state.items().size()==24,"24 records");var f=show(p,s,w,h,density);click(p,f,"open");f=show(p,s,w,h,density);
      save(s,"modal-"+w+"x"+h+"-"+density+".png");
      var bounds=f.presentation().box(new NodeId("picker/scroll")).clip();float baseOffset=p.scroll().offset();
      boolean reached=false;for(int i=0;i<80;i++){
        var b=f.presentation().box(new NodeId("item/minecraft:cookie"));var r=b.hit();float x=r.x()+r.width()/2,y=r.y()+r.height()/2;
        if(b.clip().contains(x,y)){reached=true;break;}
        check(p.input.scroll(bounds.x()+10,bounds.y()+10,0,-1),"modal wheel");f=show(p,s,w,h,density);
      }
      check(reached,"last record reachable at "+w+"x"+h+" "+density);check(p.scroll().offset()==baseOffset,"base scroll unchanged");
      check(p.visibleIconIds(f).contains("minecraft:cookie"),"icon request uses the newly scrolled current frame");
      click(p,f,"item/minecraft:cookie");f=show(p,s,w,h,density);click(p,f,"confirm");check("minecraft:cookie".equals(p.state.submitted()),"commit cookie");
      f=show(p,s,w,h,density);click(p,f,"open");f=show(p,s,w,h,density);check("minecraft:cookie".equals(p.state.selected()),"reopen initializes committed selection");
      click(p,f,"cancel");f=show(p,s,w,h,density);check("minecraft:cookie".equals(p.state.submitted()),"cancel keeps commit");
      key(p,KeyEvent.Key.ENTER);f=show(p,s,w,h,density);check(f.presentation().paintOrder().contains(new NodeId("picker")),"base focus restored to open");click(p,f,"cancel");show(p,s,w,h,density);
      System.out.println("PASS modal reach/submit/reopen/cancel "+w+"x"+h+" density="+density);
    }
  }
  public static void main(String[] args)throws Exception{
    try(var mod=TrialChecks.class.getResourceAsStream("/fabric.mod.json");var mixin=TrialChecks.class.getResourceAsStream("/creatortrial.mixins.json")){
      check(mod!=null&&mixin!=null,"client metadata resources");var metadata=new String(mod.readAllBytes(),java.nio.charset.StandardCharsets.UTF_8);var config=new String(mixin.readAllBytes(),java.nio.charset.StandardCharsets.UTF_8);
      check(metadata.contains("dev.creatortrial.TrialClient")&&metadata.contains("creatortrial.mixins.json"),"client entrypoint wired");check(config.contains("dev.creatortrial.mixin")&&!config.contains("TrialClient"),"dedicated mixin package excludes client entrypoint");
      System.out.println("PASS client entrypoint and dedicated mixin metadata (compile/package only)");
    }
    for(float density:new float[]{1,1.5f,2}){scenario(1000,700,density);scenario(380,320,density);}
    try(var p=new TrialPage();var s=Surface.makeRasterN32Premul(1000,700)){
      var f=show(p,s,1000,700,1);click(p,f,"open");f=show(p,s,1000,700,1);click(p,f,"category/empty");f=show(p,s,1000,700,1);
      check(p.state.visible().isEmpty()&&p.state.selected()==null,"empty category");click(p,f,"confirm");f=show(p,s,1000,700,1);
      check(p.state.submitted()==null&&f.presentation().paintOrder().contains(new NodeId("picker")),"disabled confirm neither closes nor submits");click(p,f,"cancel");show(p,s,1000,700,1);
      System.out.println("PASS empty category and disabled confirmation");
    }
    try(var p=new TrialPage();var s=Surface.makeRasterN32Premul(1000,700)){
      var f=show(p,s,1000,700,1);click(p,f,"open");f=show(p,s,1000,700,1);
      key(p,KeyEvent.Key.TAB);key(p,KeyEvent.Key.ENTER);check("blocks".equals(p.state.category()),"keyboard selects blocks");
      f=show(p,s,1000,700,1);key(p,KeyEvent.Key.ENTER);f=show(p,s,1000,700,1);
      check(f.presentation().paintOrder().contains(new NodeId("item/minecraft:stone")),"repeated Enter preserves category focus");
      key(p,KeyEvent.Key.TAB);key(p,KeyEvent.Key.ENTER);check("tools".equals(p.state.category()),"next Tab selects tools");
      p.input.key(new KeyEvent(KeyEvent.Key.ESCAPE,true,false,false,false));f=show(p,s,1000,700,1);
      p.input.key(new KeyEvent(KeyEvent.Key.ESCAPE,true,false,false,false));p.input.key(new KeyEvent(KeyEvent.Key.ESCAPE,false,false,false,false));
      check(p.state.submitted()==null,"escape never submits");
      click(p,f,"open");f=show(p,s,1000,700,1);click(p,f,"category/food");f=show(p,s,1000,700,1);click(p,f,"item/minecraft:apple");f=show(p,s,1000,700,1);click(p,f,"category/blocks");
      check(p.state.selected()==null,"hidden draft cleared");f=show(p,s,1000,700,1);click(p,f,"cancel");
      System.out.println("PASS category keyboard focus, held Escape, filtering");
    }
  }
}
